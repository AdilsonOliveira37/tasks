export default {
    fontFamily: 'Lato',
    colors: {
        today: '#06C59C',
        secondary: '#FFF',
        mainText: '#222',
        subText: '#555',
    }
}