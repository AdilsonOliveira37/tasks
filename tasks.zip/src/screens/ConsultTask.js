import React, { Component } from 'react'
import { Modal, Text, View, Picker, StyleSheet, TouchableWithoutFeedback, TouchableOpacity, TextInput, Platform } from 'react-native'



export default class ConsultTask extends Component {

    render(){
        return(
            <Modal transparent={true}>
                <Picker>
                    <Picker.Item label="Java" value="java" />
                    <Picker.Item label="JavaScript" value="js" />
                </Picker>
            </Modal>
        )
    }

}